DAVID CALCULATOR — Android Java project

This is a small beginner-friendly Android calculator.
Package: com.david.calculator
Language: Java
Minimum Android: 6.0 (API 23)

Build in GitHub Actions:
1. Create a GitHub repository.
2. Upload this project folder's contents, keeping folder structure.
3. Add .github/workflows/android.yml (see workflow file supplied separately in the chat).
4. Open the Actions tab and run the workflow.
5. Download the app-debug artifact and install it on your Android phone.

No special permissions are requested. Debug APK is for testing.
