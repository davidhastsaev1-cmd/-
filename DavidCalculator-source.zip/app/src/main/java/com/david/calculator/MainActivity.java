package com.david.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private TextView display, expression;
    private String current = "0";
    private double stored = 0;
    private String operator = "";
    private boolean startNew = false;
    private final int bg = Color.rgb(16, 16, 16);
    private final int panel = Color.rgb(35, 35, 35);
    private final int orange = Color.rgb(255, 152, 0);
    private final DecimalFormat format = new DecimalFormat("0.##########");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(14));
        root.setBackgroundColor(bg);

        TextView title = new TextView(this);
        title.setText("DAVID CALCULATOR");
        title.setTextColor(orange);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        expression = new TextView(this);
        expression.setText("");
        expression.setTextColor(Color.LTGRAY);
        expression.setTextSize(18);
        expression.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
        root.addView(expression, new LinearLayout.LayoutParams(-1, 0, 1));

        display = new TextView(this);
        display.setText("0");
        display.setTextColor(Color.WHITE);
        display.setTextSize(42);
        display.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.setSingleLine(true);
        root.addView(display, new LinearLayout.LayoutParams(-1, dp(86)));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        String[][] keys = {
            {"AC", "⌫", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"±", "0", ".", "="}
        };
        for (String[] row : keys) {
            for (String key : row) {
                Button button = new Button(this);
                button.setText(key);
                button.setTextSize(22);
                button.setAllCaps(false);
                button.setTextColor(Color.WHITE);
                button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    isOperator(key) ? orange : (key.equals("AC") || key.equals("⌫") || key.equals("%") || key.equals("±") ? 0xFF555555 : panel)
                ));
                GridLayout.LayoutParams p = new GridLayout.LayoutParams();
                p.width = 0;
                p.height = dp(66);
                p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
                p.setMargins(dp(4), dp(4), dp(4), dp(4));
                grid.addView(button, p);
                button.setOnClickListener(v -> press(key));
            }
        }
        root.addView(grid);
        setContentView(root);
    }

    private boolean isOperator(String s) {
        return s.equals("÷") || s.equals("×") || s.equals("−") || s.equals("+") || s.equals("=");
    }

    private void press(String key) {
        if (key.matches("[0-9]")) {
            if (startNew || current.equals("0")) current = key;
            else if (current.length() < 14) current += key;
            startNew = false;
            display.setText(current);
            return;
        }
        if (key.equals(".")) {
            if (startNew) { current = "0"; startNew = false; }
            if (!current.contains(".")) current += ".";
            display.setText(current);
            return;
        }
        if (key.equals("AC")) {
            current = "0"; stored = 0; operator = ""; startNew = false;
            expression.setText(""); display.setText(current); return;
        }
        if (key.equals("⌫")) {
            if (!startNew && current.length() > 1) current = current.substring(0, current.length()-1);
            else current = "0";
            display.setText(current); return;
        }
        if (key.equals("±")) {
            if (!current.equals("0")) current = current.startsWith("-") ? current.substring(1) : "-" + current;
            display.setText(current); return;
        }
        if (key.equals("%")) {
            current = format.format(Double.parseDouble(current) / 100.0);
            display.setText(current); return;
        }
        if (isOperator(key) && !key.equals("=")) {
            stored = Double.parseDouble(current);
            operator = key;
            expression.setText(format.format(stored) + " " + operator);
            startNew = true; return;
        }
        if (key.equals("=") && !operator.isEmpty()) {
            double second = Double.parseDouble(current);
            double result;
            switch (operator) {
                case "+": result = stored + second; break;
                case "−": result = stored - second; break;
                case "×": result = stored * second; break;
                case "÷":
                    if (second == 0) {
                        display.setText("На ноль нельзя");
                        expression.setText("");
                        current = "0"; operator = ""; startNew = true; return;
                    }
                    result = stored / second; break;
                default: return;
            }
            current = format.format(result);
            expression.setText(format.format(stored) + " " + operator + " " + format.format(second) + " =");
            display.setText(current);
            operator = ""; startNew = true;
        }
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
